// Cloudflare Pages Function at /api/create-order. Placeholder: no payments are processed.
// Later: look up price from a server-side product list, create the Razorpay order using env.RAZORPAY_KEY_SECRET.
export const onRequestPost = async () =>
  new Response(JSON.stringify({ error: 'Payments not enabled yet' }), { status: 501, headers: { 'Content-Type': 'application/json' } })
