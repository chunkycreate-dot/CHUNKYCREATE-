// ★ THE ONE FILE TO EDIT FOR PRODUCTS. Add a product = add one object to the array.
export type Status = 'coming-soon' | 'available'
export interface Product {
  id: string; slug: string; name: string
  description: string; longDescription: string
  whatYouGet: string[]; whoItsFor: string[]
  price: number | null            // INR, e.g. 199. null = "price coming soon"
  status: Status
  image: string | null            // e.g. '/products/product-01.png' (put file in /public/products). null = built-in illustration
  color: 'royal' | 'teal' | 'orange' | 'sun'
  downloadUrl: string | null      // NEVER a public link. Store only the private R2 object key, e.g. 'pdfs/product-01.pdf'
  razorpayId: string | null       // Razorpay reference, used only by the backend
}
const placeholder = {
  description: 'A digital resource from ChunkyCreate.',
  longDescription: 'Details for this product are coming soon. It is part of ChunkyCreate: digital products, AI resources and creative tools built to help you create, learn and build.',
  whatYouGet: ['Product details coming soon'], whoItsFor: ['Details coming soon'],
  price: null, status: 'coming-soon' as Status, image: null, downloadUrl: null, razorpayId: null,
}
export const products: Product[] = [
  { ...placeholder, id: 'product-01', slug: 'product-01', name: 'Digital Product 01', color: 'royal' },
  { ...placeholder, id: 'product-02', slug: 'product-02', name: 'Digital Product 02', color: 'teal' },
]
export const getProduct = (slug?: string) => products.find(p => p.slug === slug)
export const formatPrice = (p: number | null) => (p == null ? 'Price coming soon' : `₹${p}`)
