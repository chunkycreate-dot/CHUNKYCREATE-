import type { Product } from '../data/products'
// Called by BUY NOW once a product's status is 'available'.
// Flow: POST /api/create-order -> Razorpay Checkout -> POST /api/verify -> /api/download (short-lived signed R2 URL).
// Razorpay SECRET and R2 credentials live only in Cloudflare Pages Functions env vars, never in this frontend.
export async function startCheckout(product: Product) {
  const res = await fetch('/api/create-order', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ productId: product.id }) })
  if (!res.ok) throw new Error('Checkout is not enabled yet')
  // TODO: load https://checkout.razorpay.com/v1/checkout.js and open it with the returned order
}
