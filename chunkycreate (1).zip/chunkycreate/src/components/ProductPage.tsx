import { useEffect, useState } from 'react'
import { Link, useParams } from 'react-router-dom'
import { getProduct, formatPrice } from '../data/products'
import { CoverArt, bg } from './Art'
import { startCheckout } from '../lib/checkout'

export default function ProductPage() {
  const { slug } = useParams(); const p = getProduct(slug); const [err, setErr] = useState('')
  useEffect(() => { document.title = p ? `${p.name} — ChunkyCreate` : 'Not found — ChunkyCreate'; window.scrollTo(0, 0) }, [p])
  if (!p) return <div className="wrap py-24"><h1 className="text-5xl">Product not found</h1><Link to="/#products" className="btn bg-orange mt-6">Back to products</Link></div>
  const soon = p.status === 'coming-soon'
  const List = ({ items }: { items: string[] }) => <ul className="mt-3 grid gap-2">{items.map(i => <li key={i} className="flex gap-3"><span className="font-display text-orange">■</span>{i}</li>)}</ul>
  return (
    <article className="wrap pt-8">
      <Link to="/#products" className="font-bold underline">← Back to products</Link>
      <div className="mt-6 grid md:grid-cols-2 gap-10">
        <div className={`card ${bg[p.color]} p-6 self-start hover:!translate-y-0 hover:!rotate-0`}><div className="bg-cream/20 rounded-2xl p-3">{p.image ? <img src={p.image} alt={p.name} className="rounded-xl w-full" /> : <CoverArt tone={p.color} />}</div></div>
        <div>
          <h1 className="text-5xl md:text-6xl text-royal">{p.name}</h1>
          <p className="mt-4 text-xl">{p.description}</p>
          <p className="mt-5 flex flex-wrap items-center gap-4"><span className="font-display text-4xl">{formatPrice(p.price)}</span>
            <span className="border-2 border-ink rounded-full px-3 py-1 font-bold text-sm">{soon ? 'COMING SOON' : 'AVAILABLE'}</span></p>
          {soon ? <button disabled className="btn bg-sun mt-6 opacity-70 cursor-not-allowed">Coming soon</button>
            : <button className="btn bg-orange mt-6" onClick={() => startCheckout(p).catch(e => setErr(e.message))}>Buy now</button>}
          {err && <p role="alert" className="mt-3 font-bold text-orange">{err}</p>}
          <h2 className="text-3xl mt-10">About this product</h2><p className="mt-3 text-lg">{p.longDescription}</p>
          <h2 className="text-3xl mt-8">What you'll get</h2><List items={p.whatYouGet} />
          <h2 className="text-3xl mt-8">Who it's for</h2><List items={p.whoItsFor} />
        </div>
      </div>
    </article>
  )
}
